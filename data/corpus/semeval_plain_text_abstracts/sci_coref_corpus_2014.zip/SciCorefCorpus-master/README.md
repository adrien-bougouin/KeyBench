SciCorefCorpus
==============

Corpus for coreference resolution on scientific papers in multiple domains
